//-----Friends Profile Start----

// Blocked Menu(三个点按钮)
var blockedmenu = document.querySelector(".blocked-menu");

function blockedMenuToggle(){
  blockedmenu.classList.toggle("blocked-menu-height");
}
