//-----Friends Profile Start----

// Profile Friend Menu(Friend按钮)
var friendmenu = document.querySelector(".profile-friend-menu");

function friendMenuToggle(){
  friendmenu.classList.toggle("profile-friend-menu-height");
}